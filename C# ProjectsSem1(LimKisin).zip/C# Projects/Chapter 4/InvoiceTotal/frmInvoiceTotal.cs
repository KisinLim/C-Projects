﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EnhancedInvoiceTotal
{
    public partial class frmInvoiceTotal : Form
    {
        public frmInvoiceTotal()
        {
            InitializeComponent();
        }      

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
        int numberOfInvoices = 0;
        decimal totalOfInvoice = 0m;
        decimal invoiceAverage = 0m; 
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal subtotal = Convert.ToDecimal(txtEnterSubtotal.Text);
            decimal discountPercent = 0.25m;
            decimal discountAmount = Math.Round(subtotal * discountPercent, 2);
            decimal invoiceTotal = subtotal - discountAmount;
            txtSubtotal.Text = subtotal.ToString("c");
            txtDiscountPercent.Text = discountPercent.ToString("p1");
            txtDiscountAmount.Text = discountAmount.ToString("c");
            txtTotal.Text = totalOfInvoice.ToString("c");
            numberOfInvoices++;
            totalOfInvoice += invoiceTotal;
            invoiceAverage = totalOfInvoice / numberOfInvoices;
            
            txtNumberOfInvoices.Text = numberOfInvoices.ToString();
            txtTotalOfInvoice.Text = totalOfInvoice.ToString("c");
            txtInvoiceAverage.Text = invoiceAverage.ToString();

            txtEnterSubtotal.Text = "";
            txtEnterSubtotal.Focus();
        }

        private void btnClearTotals_Click(object sender, EventArgs e)
        {
            numberOfInvoices = 0;
            totalOfInvoice = 0m;
            invoiceAverage = 0m;

            txtNumberOfInvoices.Text = "";
            txtTotalOfInvoice.Text = "";
            txtInvoiceAverage.Text = "";

            txtEnterSubtotal.Focus();
        }
    }
}

