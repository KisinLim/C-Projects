﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project05__StudentPopulation_
{
    public partial class frmStudentPopulation : Form
    {
        public frmStudentPopulation()
        {
            InitializeComponent();
        }

        private void btnProjectStudentPopulation_Click(object sender, EventArgs e)
        {
            double numberOfStudentsToday = Convert.ToDouble(txtNumberOfStudentsToday.Text);
            float annualGrowthRate = float.Parse(txtAnnualGrowthRate.Text);
            int numberOfYear = Convert.ToInt32(txtNumberOfYears.Text);
            for ( int year = 1; year <= numberOfYear; year++)
            {
                numberOfStudentsToday =  numberOfStudentsToday * (1 + annualGrowthRate);
            }
            txtProjectedNumberOfStudents.Text = numberOfStudentsToday.ToString("N0");
            txtNumberOfStudentsToday.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
