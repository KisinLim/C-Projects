﻿namespace Project05__StudentPopulation_
{
    partial class frmStudentPopulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNumberOfStudentsToday = new System.Windows.Forms.TextBox();
            this.txtAnnualGrowthRate = new System.Windows.Forms.TextBox();
            this.txtNumberOfYears = new System.Windows.Forms.TextBox();
            this.txtProjectedNumberOfStudents = new System.Windows.Forms.TextBox();
            this.btnProjectStudentPopulation = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of students today";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Annual growth rate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 119);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number of years";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 161);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(229, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Projected number of students";
            // 
            // txtNumberOfStudentsToday
            // 
            this.txtNumberOfStudentsToday.Location = new System.Drawing.Point(301, 31);
            this.txtNumberOfStudentsToday.Name = "txtNumberOfStudentsToday";
            this.txtNumberOfStudentsToday.Size = new System.Drawing.Size(145, 27);
            this.txtNumberOfStudentsToday.TabIndex = 0;
            this.txtNumberOfStudentsToday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAnnualGrowthRate
            // 
            this.txtAnnualGrowthRate.Location = new System.Drawing.Point(301, 73);
            this.txtAnnualGrowthRate.Name = "txtAnnualGrowthRate";
            this.txtAnnualGrowthRate.Size = new System.Drawing.Size(145, 27);
            this.txtAnnualGrowthRate.TabIndex = 1;
            this.txtAnnualGrowthRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfYears
            // 
            this.txtNumberOfYears.Location = new System.Drawing.Point(301, 116);
            this.txtNumberOfYears.Name = "txtNumberOfYears";
            this.txtNumberOfYears.Size = new System.Drawing.Size(145, 27);
            this.txtNumberOfYears.TabIndex = 2;
            this.txtNumberOfYears.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtProjectedNumberOfStudents
            // 
            this.txtProjectedNumberOfStudents.Location = new System.Drawing.Point(301, 158);
            this.txtProjectedNumberOfStudents.Name = "txtProjectedNumberOfStudents";
            this.txtProjectedNumberOfStudents.ReadOnly = true;
            this.txtProjectedNumberOfStudents.Size = new System.Drawing.Size(145, 27);
            this.txtProjectedNumberOfStudents.TabIndex = 7;
            this.txtProjectedNumberOfStudents.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnProjectStudentPopulation
            // 
            this.btnProjectStudentPopulation.Location = new System.Drawing.Point(194, 228);
            this.btnProjectStudentPopulation.Name = "btnProjectStudentPopulation";
            this.btnProjectStudentPopulation.Size = new System.Drawing.Size(95, 73);
            this.btnProjectStudentPopulation.TabIndex = 3;
            this.btnProjectStudentPopulation.Text = "&Project Student Population";
            this.btnProjectStudentPopulation.UseVisualStyleBackColor = true;
            this.btnProjectStudentPopulation.Click += new System.EventHandler(this.btnProjectStudentPopulation_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(342, 228);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(89, 73);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "E&xir";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmStudentPopulation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 351);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnProjectStudentPopulation);
            this.Controls.Add(this.txtProjectedNumberOfStudents);
            this.Controls.Add(this.txtNumberOfYears);
            this.Controls.Add(this.txtAnnualGrowthRate);
            this.Controls.Add(this.txtNumberOfStudentsToday);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmStudentPopulation";
            this.Text = "Student Population";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNumberOfStudentsToday;
        private System.Windows.Forms.TextBox txtAnnualGrowthRate;
        private System.Windows.Forms.TextBox txtNumberOfYears;
        private System.Windows.Forms.TextBox txtProjectedNumberOfStudents;
        private System.Windows.Forms.Button btnProjectStudentPopulation;
        private System.Windows.Forms.Button btnExit;
    }
}

