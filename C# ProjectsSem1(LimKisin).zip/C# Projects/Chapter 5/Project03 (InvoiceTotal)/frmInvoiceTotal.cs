﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTotal02
{
    public partial class frmInvoiceTotal : Form
    {
        public frmInvoiceTotal()
        {
            InitializeComponent();
        }      
        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalculate_Click_1(object sender, EventArgs e)
        {
            string customerType = txtCustomerType.Text;
            decimal subtotal = Convert.ToDecimal(txtSubtotal.Text);
            decimal discountPercent = .0m;

            if (customerType == "R" || customerType == "r" )
            {
                if (subtotal <= 100)
                    discountPercent = .0m;
                else if (subtotal > 100)
                    discountPercent = 0.1m;
                else if (subtotal >= 250)
                    discountPercent = .25m;
            }
            else if (customerType == "C" || customerType == "c")
            {
                if (subtotal < 250)
                    discountPercent = .2m;
                else
                    discountPercent = .3m;
            }
            else
            {
                discountPercent = 0.4m;
            }
            decimal discountAmount =(subtotal * discountPercent);
            decimal total = subtotal - discountAmount;

            txtDiscountPercent.Text = discountPercent.ToString("p1");
            txtDiscountAmount.Text = discountAmount.ToString("c");
            txtTotal.Text = total.ToString("c");
     
            txtCustomerType.Focus();
        }
    }
}
