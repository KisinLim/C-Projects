﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ShippingAndHanding
{
    public partial class frmShippingAndHanding : Form
    {
        public frmShippingAndHanding()
        {
            InitializeComponent();
        }    
        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalculateGrandTotal_Click_1(object sender, EventArgs e)
        {
            decimal orderTotal = Convert.ToDecimal(txtOrderTotal.Text);
            string customerType = txtCustomerType.Text.ToUpper();
            decimal shippingCosts = 0m;
            decimal salesTax = 0m;
            decimal grandTotal = 0m;
            if (customerType == "P" || customerType == "p")
            {
                lblShippingCosts.Text = shippingCosts.ToString("c");
                lblSalesTax.Text = salesTax.ToString("c");
                lblGrandTotal.Text = grandTotal.ToString("c");
            }
            else if (customerType == "N")
            {
                if (orderTotal >= 0 && orderTotal <= 25)
                {
                    shippingCosts = 5m;
                    
                }
                else if (orderTotal >= 25 && orderTotal <= 500)
                {
                    shippingCosts = 8m;
                    
                }
                else if (orderTotal >= 500 && orderTotal <= 1000)
                {
                    shippingCosts = 10m;
                    
                }
                else if (orderTotal >= 1000 && orderTotal <= 5000)
                {
                    shippingCosts = 15m;
                    
                }
                else if (orderTotal >= 5000)
                {
                    shippingCosts = 20m;
                    
                }
            }
            lblShippingCosts.Text = shippingCosts.ToString("c");
            salesTax = (7 * (orderTotal + shippingCosts)) / 100;
            lblSalesTax.Text = salesTax.ToString("c");
            grandTotal = (orderTotal + shippingCosts) + salesTax;
            lblGrandTotal.Text = grandTotal.ToString("c");

        }
    }
}
