﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculateLetterGrade
{
    public partial class frmCalculateLetterGrade : Form
    {
        public frmCalculateLetterGrade()
        {
            InitializeComponent();
        }

        private void btnCalculateLetterGrade_Click(object sender, EventArgs e)
        {
            decimal numericGrade = Convert.ToDecimal(txtNumericGrade.Text);
            if (numericGrade >=90 && numericGrade <= 100)
            {
                lblLetterGrade.Text = ("A");
            }
            else if (numericGrade >= 80 && numericGrade <= 89 )
            {
                lblLetterGrade.Text= ("B");
            }
            else if (numericGrade >= 70 && numericGrade <= 79)
            {
                lblLetterGrade.Text= ("C");
            }
            else if (numericGrade >= 60 && numericGrade <= 69)
            {
                lblLetterGrade.Text = ("D");
            }
            else if (numericGrade >= 50 && numericGrade <= 59)
            {
                lblLetterGrade.Text = ("E");
            }
            else if (numericGrade >100)
            {
                this.Close();
            }
            else
            {
                lblLetterGrade.Text = ("F");
            }
            txtNumericGrade.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();   
        }
    }
}
