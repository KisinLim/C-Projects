﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payment
{
    public partial class frmCustomer : Form
    {
        public frmCustomer()
        {
            InitializeComponent();
        }
        bool isDataSave = true;
        private void frmCustomer_Load(object sender, System.EventArgs e)
        {
            cboNames.Items.Add("Mike Smith");
            cboNames.Items.Add("Nancy Jones");
        }
        private void DataChanged(object sender, System.EventArgs e)
        {
            isDataSave = false;
        }
        private void btnSelectPayment_Click(object sender, EventArgs e)
        {
            Form paymentForm = new frmPayment();
            DialogResult selectedButton = paymentForm.ShowDialog();

            if (selectedButton == DialogResult.OK)
            {
                lblPayment.Text = (string)paymentForm.Tag;
            }
        }

        private void btnSave_Click(object sender, System.EventArgs e)
        {
           if (IsvalidData)
        }
    }
}
