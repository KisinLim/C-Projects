﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTotal02
{
    public partial class frmInvoiceTotalO1 : Form
    {
        public frmInvoiceTotalO1()
        {
            InitializeComponent();
        }

        private void InvoiceTotal02_Load(object sender, EventArgs e)
        {

        }
    }
}
