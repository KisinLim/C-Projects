﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Project04__FutureValue_
{
    public partial class frmFutureValue : Form
    {
        public frmFutureValue()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click_1(object sender, EventArgs e)
        {
            decimal monthlyInvestment = Convert.ToDecimal(txtMonthlyInvestment.Text);
            decimal yearlyInterestRate = Convert.ToDecimal(txtYearlyInterestRate.Text);
            int numberOfYears = Convert.ToInt32(txtNumberOfYears.Text);
            int months = numberOfYears * 12;
            decimal monthlyInterestRate = yearlyInterestRate / 12 / 100;
            decimal futureValue = CalculateFutureValue(monthlyInvestment,months,monthlyInterestRate);
            txtFutureValue.Text = futureValue.ToString("c");
            txtMonthlyInvestment.Focus();
        }
        public decimal CalculateFutureValue(Decimal monthlyInvestment, int months, decimal monthlyInterestRate)
        {
            Decimal futureValue = 0m;
            for (int i = 0; i < months; i++)
            {
                futureValue = (futureValue + monthlyInvestment) * (1 + monthlyInterestRate);
            }

            return futureValue;
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void ClearFutureValue(object sender, EventArgs e)
        {
            txtFutureValue.Text = "";
        }


        
    }
}
